//inGameMusic.mp3

//After menu : TP in room
//Tuto part 1 : Movements
	//Hi, welcome to our experiments center. We'll teach you how to move by yourself in a few seconds.
	//First, you have to understand what to do. Your goal is to go from your current position to the exit door,
	//right here (Show exit door).
	//You see this green zone under your feets ? It's where you can configurate your movements, by pressing
	//ZQSD several times, you increase your chances to move in a direction. Then, you can press SPACEBAR to execute
	//your movements and see what's going on. Let's try this !
//Tuto part 2 : Objects
	//Now you see there's a box and a pressure plate. As you can imagine, the box will activate the pressure plate
	//if you put it on. Of course, the exit door is locked if you don't do it. Let's go !
//Game